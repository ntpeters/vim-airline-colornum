#Airline Color Num Plugin

Sets the cursor line number to the same color as the current mode in the
statusline set by the Vim Airline plugin.

